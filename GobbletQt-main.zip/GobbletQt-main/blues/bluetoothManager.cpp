#include "bluetoothManager.h"
#include <QDebug>
#include <QCoreApplication>
#include <QBluetoothPermission>

/*
┌────────────────────────────────────────────────────────────┐
│ Primary Service                                            │
│ UUID: 12345678-6398-4c4c-80cb-2cc15d4734d7                 │
└────────────────────────────────────────────────────────────┘
        │
        ├── Characteristic: RX  (Client → Server)
        │
        │   UUID: beefbbbb-6398-4c4c-80cb-2cc15d4734d7
        │
        │   Properties:
        │     • Write
        │     • Write Without Response
        │
        │   Permissions:
        │     • Writeable
        │
        │   Descriptors:
        │     • (none)
        │
        │   Data Flow:
        │     Client  ── write() ──▶  Server
        │
        │   Qt signal:
        │     QLowEnergyService::characteristicWritten()
        │
        └── Characteristic: TX  (Server → Client)
            │
            │   UUID: feedaaaa-6398-4c4c-80cb-2cc15d4734d7
            │
            │   Properties:
            │     • Notify
            │
            │   Permissions:
            │     • Readable (implicit)
            │
            │   Descriptors:
            │     • Client Characteristic Configuration (CCC)
            │       UUID: 00002902-0000-1000-8000-00805f9b34fb
            │
            │   Data Flow:
            │     Server ── notify() ──▶ Client
            │
            │   Qt signal:
            │     QLowEnergyService::characteristicChanged()

createCentral()
   ↓
connectToDevice()
   ↓
ConnectedState
   ↓
discoverServices()
   ↓
serviceDiscovered(uuid)
   ↓
createServiceObject()
   ↓
discoverDetails()
   ↓
ServiceDiscovered
   ↓
RX/TX characteristics valid

You → ask Qt to connect
Qt → connects
Qt → asks device for services
Device → responds
Qt → emits serviceDiscovered(uuid)
You → react
 */

BluetoothManager::BluetoothManager(QObject *parent)
    : QObject(parent)
{

}

BluetoothManager::~BluetoothManager()
{
    stopDiscovery();
    stopServer();
}

void BluetoothManager::startServer()
{

#if QT_CONFIG(permissions)
    QBluetoothPermission btPerm;

    auto status = qApp->checkPermission(btPerm);

    if (status == Qt::PermissionStatus::Undetermined) {

        qApp->requestPermission(btPerm, this, [this](const QPermission &p) {
            if (p.status() == Qt::PermissionStatus::Granted) {
                this->startServer();  // retry
            } else {
                emit serverError("Bluetooth permission denied");
            }
        });
        return;
    }

    if (status == Qt::PermissionStatus::Denied) {
        emit serverError("Bluetooth permission denied");
        return;
    }
#endif

    stopServer();

    qDebug() << "Initializing BLE ChatServer...";

    server = new ChatServer(this);

    connect(server, &ChatServer::messageReceived,
            this, &BluetoothManager::serverMessage);
    connect(server, &ChatServer::clientConnected, this, [](const QString &){ qDebug() << "Client connected"; });
    connect(server, &ChatServer::clientDisconnected, this, [](const QString &){ qDebug() << "Client disconnected"; });
    connect(server, &ChatServer::serverError, this, &BluetoothManager::onServerError);
    //connect(this, &BluetoothManager::sendToClient, server, &ChatServer::sendMessage);

    server->startServer(serviceUuid, rxCharUuid, txCharUuid);
    m_role = Role::Server;

    setServerName("Gobblet Online");
}

void BluetoothManager::stopServer()
{
    if (server) {
        server->stopServer();
        server->deleteLater();
        server = nullptr;
    }
    m_role = Role::None;
}

void BluetoothManager::startDiscovery()
{
    stopDiscovery();
    discoveryAgent = new QBluetoothDeviceDiscoveryAgent(this);

    // Optional: give macOS enough time
    discoveryAgent->setLowEnergyDiscoveryTimeout(8000);

    connect(discoveryAgent, &QBluetoothDeviceDiscoveryAgent::deviceDiscovered,
            this, &BluetoothManager::onDeviceDiscovered);

    connect(discoveryAgent, &QBluetoothDeviceDiscoveryAgent::finished,
            this, &BluetoothManager::discoveryFinished);

    connect(discoveryAgent, &QBluetoothDeviceDiscoveryAgent::canceled,
            this, &BluetoothManager::discoveryFinished); // macOS workaround

    qDebug() << "Starting BLE device discovery...";

    discoveryAgent->start(QBluetoothDeviceDiscoveryAgent::LowEnergyMethod);
}

void BluetoothManager::stopDiscovery()
{    
    if (discoveryAgent) {
        discoveryAgent->stop();
        discoveryAgent->deleteLater();
        discoveryAgent = nullptr;
    }
}

void BluetoothManager::onDeviceDiscovered(const QBluetoothDeviceInfo &info)
{
    if (!(info.coreConfigurations() & QBluetoothDeviceInfo::LowEnergyCoreConfiguration))
        return;

    const QString name = info.name();
    if (name.isEmpty())
        return;

    // Exclude devices with the same name
    for (const QBluetoothDeviceInfo &d : std::as_const(foundDevices)) {
        if (d.name() == name) {
            return; // already known
        }
    }

    qDebug() << "Found BLE device:" << info.name() << info.address().toString();
    foundDevices.append(info);
}

void BluetoothManager::discoveryFinished()
{
    qDebug() << "BLE device discovery finished.";
    if (foundDevices.isEmpty())
        qDebug() << "No BLE devices found.";
}

void BluetoothManager::connectWithName(const QString &name)
{
    for (const QBluetoothDeviceInfo &d : std::as_const(foundDevices)) {
        if (d.name().contains(name, Qt::CaseInsensitive)) {
            stopDiscovery();
            connectToDevice(d);
            break;
        }
    }
}

void BluetoothManager::stopClient() {
    if (client) {
        client->disconnect(this); // disconnect all signals
        client->deleteLater();
        client = nullptr;
    }
    m_role = Role::None;
}

void BluetoothManager::connectToDevice(const QBluetoothDeviceInfo &device)
{
    qDebug() << "Connecting to device:" << device.name();

    stopClient();
    client = new ChatClient(this);

    connect(client, &ChatClient::connected, this, [](){ qDebug() << "Client connected to remote"; });
    connect(client, &ChatClient::disconnected, this, [](){ qDebug() << "Client disconnected"; });
    connect(client, &ChatClient::messageReceived, this, &BluetoothManager::clientMessage);
    //connect(this, &BluetoothManager::sendToServer, client, &ChatClient::sendMessage);

    // Start BLE connection
    client->startClient(device, serviceUuid, rxCharUuid, txCharUuid);
    m_role = Role::Client;

    setClientName(device.name());
}

QVariantList BluetoothManager::getDevices() {
    QVariantList devices;
    for (const QBluetoothDeviceInfo &d : std::as_const(foundDevices)) {
        QVariantMap device;
        device["name"] = d.name();
        device["address"] = d.address().toString();
        devices.append(device);
    }
    // start discovery if empty
    if (foundDevices.isEmpty()) {
        startDiscovery();
    }
    return devices;
}

void BluetoothManager::sendMessage(const QString &msg)
{
    if (m_role == Role::Client && client) {
        client->sendMessage(msg);     // RX write
    }
    else if (m_role == Role::Server && server) {
        server->sendMessage(msg);     // TX notify
    }
}

void BluetoothManager::onServerError(const QString &message)
{
    qWarning() << "[BluetoothManager] Server error:" << message;
}
