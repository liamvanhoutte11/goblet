#ifndef BOARD3D_H
#define BOARD3D_H
#include "shape3d.h"

class Board3d : public Shape3d
{
public:
    Board3d();
};

#endif // BOARD3D_H
