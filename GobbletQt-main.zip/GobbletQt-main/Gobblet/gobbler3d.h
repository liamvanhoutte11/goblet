#ifndef GOBBLER3D_H
#define GOBBLER3D_H
#include "shape3d.h"

class Gobbler3d : public Shape3d
{
public:
    Gobbler3d(double size);
};

#endif // GOBBLER3D_H
